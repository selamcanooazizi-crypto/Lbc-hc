package dev.itemdrop;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class DropRenderer {

    public static void render(WorldRenderContext ctx) {
        if (!Config.enabled || DropTracker.paths.isEmpty()) return;

        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;
        Vec3d cam = ctx.camera().getPos();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getRenderTypeLinesProgram);
        RenderSystem.lineWidth(2.0f);

        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
        MatrixStack.Entry entry = matrices.peek();

        // Speed 1 = 0.5x ... 5 = 2.5x (20 adim/sn baz)
        double stepsPerSecond = 20.0 * Config.speed * 0.5;
        double t = (System.nanoTime() / 1_000_000_000.0) * stepsPerSecond;

        for (DropTracker.Path p : DropTracker.paths) {
            List<Vec3d> pts = p.points;
            int segs = pts.size() - 1;
            if (segs < 1) continue;

            int rgb = p.rgb;
            int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;

            // Ana cizgi
            for (int i = 0; i < segs; i++) {
                Vec3d a = pts.get(i).subtract(cam);
                Vec3d c = pts.get(i + 1).subtract(cam);
                line(entry, buf, a.x, a.y, a.z, c.x, c.y, c.z, r, g, b, 150);
            }

            // Dusecegi nokta: yerde kare
            Vec3d land = pts.get(segs).subtract(cam);
            double x = land.x, y = land.y + 0.02, z = land.z, h = 0.25;
            line(entry, buf, x - h, y, z - h, x + h, y, z - h, r, g, b, 255);
            line(entry, buf, x + h, y, z - h, x + h, y, z + h, r, g, b, 255);
            line(entry, buf, x + h, y, z + h, x - h, y, z + h, r, g, b, 255);
            line(entry, buf, x - h, y, z + h, x - h, y, z - h, r, g, b, 255);

            // Cizgi boyunca akan parlak parca (Speed ile hizlanir / yavaslar)
            double idx = t % segs;
            int i0 = (int) idx;
            double f = idx - i0;
            Vec3d s0 = pts.get(i0).lerp(pts.get(i0 + 1), f).subtract(cam);
            int i1 = Math.min(i0 + 1, segs - 1);
            Vec3d s1 = pts.get(i1).lerp(pts.get(i1 + 1), f).subtract(cam);
            line(entry, buf, s0.x, s0.y, s0.z, s1.x, s1.y, s1.z, 255, 255, 255, 255);
        }

        BuiltBuffer built = buf.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);

        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void line(MatrixStack.Entry e, VertexConsumer vc,
                             double x1, double y1, double z1,
                             double x2, double y2, double z2,
                             int r, int g, int b, int a) {
        float dx = (float) (x2 - x1), dy = (float) (y2 - y1), dz = (float) (z2 - z1);
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        vc.vertex(e, (float) x1, (float) y1, (float) z1).color(r, g, b, a).normal(e, nx, ny, nz);
        vc.vertex(e, (float) x2, (float) y2, (float) z2).color(r, g, b, a).normal(e, nx, ny, nz);
    }

    private DropRenderer() {}
}
