ITEM DROP (Fabric 1.21.1, client)

- G tusu: menuyu acar/kapatir (Item Drop ON/OFF + Speed 1-5).
- Sadece bir oyuncu olunce (sen oldurursen ya da baska biri) dusen itemlar icin cizgi cikar.
  Yerde duran / olumle ilgisi olmayan itemlar gosterilmez.

JAR ALMAK (GitHub):
1) GitHub'da yeni repo ac, bu klasorun icindekileri (".github" klasoru dahil) yukle.
2) Actions sekmesi -> "build" calisir (bitince yesil tik).
3) Calisan build'e tikla -> en altta "Artifacts" -> ItemDrop-jar -> indir, zip'ten cikan jar'i mods klasorune at.
Gerekenler: Fabric Loader + Fabric API (1.21.1).

LOKALDE: JDK 21 + Gradle 8.12 ile  gradle build  -> build/libs/itemdrop-1.0.0.jar
